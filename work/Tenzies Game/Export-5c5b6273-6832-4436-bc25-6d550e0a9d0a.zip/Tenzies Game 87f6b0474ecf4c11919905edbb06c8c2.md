# Tenzies Game

Created: June 16, 2022 8:35 PM
Last Edited Time: June 16, 2022 9:17 PM

- **Visit Site:**

[Tenzies Game](https://how-to-program.github.io/Tenzies-game/)

# 📜Overview

Tenzies game is a dice game that’s usually better suited for younger children. The idea is to try and roll 10 dice to be all the same. In this game you can click on one of the dice to hold it and when you click roll those held, the dice won’t change. Click the dice until all of the dice that we roll are the same number.

As soon as you hold the last dice, the game is going to notice that you have all with same number, it’ll play a fun confetti drop, and change the buttons from “Roll” to “New Game”.

# ✏️T**echnologies/Skills**

This game is build with React, React Hooks and JavaScript. 

Uses **nanoid** to generate unique id for each dice.

Best record is saved in local storage so that it can be stored automatically for a while.

Uses react-confetti to perform the confetti drop effect. A state is created to store the page status to decide whether to change the button text and to perform the confetti drop.

# **👩🏻‍💻**Desktop Screenshots

![https://i.ibb.co/sK9sXZC/QQ-20220616203900.png](https://i.ibb.co/sK9sXZC/QQ-20220616203900.png)

![https://i.ibb.co/1rbTqnc/QQ-20220616204018.png](https://i.ibb.co/1rbTqnc/QQ-20220616204018.png)