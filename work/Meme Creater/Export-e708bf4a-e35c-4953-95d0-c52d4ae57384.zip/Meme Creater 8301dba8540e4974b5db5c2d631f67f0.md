# Meme Creater

- **Visit Site:**

[React App](https://how-to-program.github.io/Meme-Creater/)

# 📜Overview

A dynamic web app allows read & write: 

- Ability to change data
- Highly interactive
- Displays data

Display meme image and allow users to add texts on the top part and bottom part on the image to custom a meme.

# ✏️T**echnologies/Skills**

The website uses React for its frontend framework, with React Hooks and Event listeners to handle user operations and perform conditional rendering.

Click change bottom can random fetch a new meme image from the internet. The meme images are fetched using API of a public website [https://imgflip.com/](https://imgflip.com/).

## **👩🏻‍💻**Desktop Screenshots

![https://i.ibb.co/w6RPcXQ/QQ-20220606105940.png](https://i.ibb.co/w6RPcXQ/QQ-20220606105940.png)

![https://i.ibb.co/x147Dcv/QQ-20220606110222.png](https://i.ibb.co/x147Dcv/QQ-20220606110222.png)